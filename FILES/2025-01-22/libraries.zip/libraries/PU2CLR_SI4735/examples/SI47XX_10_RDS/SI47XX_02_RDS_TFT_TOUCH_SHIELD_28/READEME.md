
All Arduino DUE/MEGA examples have RDS feature. 
See folder [examples/SI47XX_16_ARDUINO_DUE_MEGA](https://github.com/pu2clr/SI4735/tree/master/examples/SI47XX_16_ARDUINO_DUE_MEGA)


